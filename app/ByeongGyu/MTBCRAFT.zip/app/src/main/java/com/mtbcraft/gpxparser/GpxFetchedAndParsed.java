package com.mtbcraft.gpxparser;

public interface GpxFetchedAndParsed {
    void onGpxFetchedAndParsed(Gpx gpx);
}
