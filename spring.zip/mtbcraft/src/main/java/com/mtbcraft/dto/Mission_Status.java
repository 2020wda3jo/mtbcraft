package com.mtbcraft.dto;

public class Mission_Status {
	private int ms_num;
	private String ms_rider;
	private int ms_type;
	private int ms_score;
	public int getMs_num() {
		return ms_num;
	}
	public void setMs_num(int ms_num) {
		this.ms_num = ms_num;
	}
	public String getMs_rider() {
		return ms_rider;
	}
	public void setMs_rider(String ms_rider) {
		this.ms_rider = ms_rider;
	}
	public int getMs_type() {
		return ms_type;
	}
	public void setMs_type(int ms_type) {
		this.ms_type = ms_type;
	}
	public int getMs_score() {
		return ms_score;
	}
	public void setMs_score(int ms_score) {
		this.ms_score = ms_score;
	}
	
	
}