package com.mtbcraft.dto;

public class Info_GPX {
	private double lat;
	private double lon;
	private double ele;
	public double getLat() {
		return lat;
	}
	public void setLat(double lat) {
		this.lat = lat;
	}
	public double getLon() {
		return lon;
	}
	public void setLon(double lon) {
		this.lon = lon;
	}
	public double getEle() {
		return ele;
	}
	public void setEle(double ele) {
		this.ele = ele;
	}
}
