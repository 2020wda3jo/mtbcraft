package com.mtbcraft.dto;

public class Like_Status {
	private String ls_rider;
	private int ls_rnum;
	public String getLs_rider() {
		return ls_rider;
	}
	public void setLs_rider(String ls_rider) {
		this.ls_rider = ls_rider;
	}
	public int getLs_rnum() {
		return ls_rnum;
	}
	public void setLs_rnum(int ls_rnum) {
		this.ls_rnum = ls_rnum;
	}
	
	
}