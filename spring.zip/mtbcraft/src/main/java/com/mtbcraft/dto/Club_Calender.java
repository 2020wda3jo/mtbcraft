package com.mtbcraft.dto;

import java.util.Date;

public class Club_Calender {
	private int cc_num;
	private int cc_club;
	private String cc_rider;
	private String cc_content;
	private String cc_start;
	private String cc_end;
	private String cc_color;
	private int cc_allday;
	
	public int getCc_num() {
		return cc_num;
	}
	public void setCc_num(int cc_num) {
		this.cc_num = cc_num;
	}
	public int getCc_club() {
		return cc_club;
	}
	public void setCc_club(int cc_club) {
		this.cc_club = cc_club;
	}
	public String getCc_rider() {
		return cc_rider;
	}
	public void setCc_rider(String cc_rider) {
		this.cc_rider = cc_rider;
	}
	public String getCc_content() {
		return cc_content;
	}
	public void setCc_content(String cc_content) {
		this.cc_content = cc_content;
	}
	public String getCc_start() {
		return cc_start;
	}
	public void setCc_start(String cc_start) {
		this.cc_start = cc_start;
	}
	public String getCc_end() {
		return cc_end;
	}
	public void setCc_end(String cc_end) {
		this.cc_end = cc_end;
	}
	public String getCc_color() {
		return cc_color;
	}
	public void setCc_color(String cc_color) {
		this.cc_color = cc_color;
	}
	public int getCc_allday() {
		return cc_allday;
	}
	public void setCc_allday(int cc_allday) {
		this.cc_allday = cc_allday;
	}
	
}
