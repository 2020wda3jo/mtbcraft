package com.mtbcraft.dto;

public class Tag_Status {
	private int ts_num;
	private String ts_rider;
	private int ts_rnum;
	private String ts_tag;
	
	public int getTs_num() {
		return ts_num;
	}
	public void setTs_num(int ts_num) {
		this.ts_num = ts_num;
	}
	public String getTs_rider() {
		return ts_rider;
	}
	public void setTs_rider(String ts_rider) {
		this.ts_rider = ts_rider;
	}
	public int getTs_rnum() {
		return ts_rnum;
	}
	public void setTs_rnum(int ts_rnum) {
		this.ts_rnum = ts_rnum;
	}
	public String getTs_tag() {
		return ts_tag;
	}
	public void setTs_tag(String ts_tag) {
		this.ts_tag = ts_tag;
	}
}
