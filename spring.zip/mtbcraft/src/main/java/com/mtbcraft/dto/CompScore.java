package com.mtbcraft.dto;

public class CompScore {
	
	private String r_nickname;
	private String r_image;
	private int rr_avgspeed;
	
	public String getR_nickname() {
		return r_nickname;
	}
	public void setR_nickname(String r_nickname) {
		this.r_nickname = r_nickname;
	}
	public String getR_image() {
		return r_image;
	}
	public void setR_image(String r_image) {
		this.r_image = r_image;
	}
	public int getRr_avgspeed() {
		return rr_avgspeed;
	}
	public void setRr_avgspeed(int rr_avgspeed) {
		this.rr_avgspeed = rr_avgspeed;
	}

	
}