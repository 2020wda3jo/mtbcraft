package com.mtbcraft.config;

public class WebConfig {

}
