package com.capston.mtbcraft;

import org.junit.Ignore;
import org.springframework.boot.test.context.SpringBootTest;

@Ignore
@SpringBootTest
class MtbcraftApplicationTests {

	void contextLoads() {
	}

}
